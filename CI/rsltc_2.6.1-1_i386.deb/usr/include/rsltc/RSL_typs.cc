/* 
RSL Type Checker
Copyright (C) 2000 UNU/IIST

raise@iist.unu.edu
*/

#include "cpp_RSL.cc"
#include "cpp_io.cc" 
#include "cpp_list.cc"
#include "cpp_set.cc"
#include "RSL_set.cc"
#include "RSL_list.cc"
#include "RSL_map.cc"
